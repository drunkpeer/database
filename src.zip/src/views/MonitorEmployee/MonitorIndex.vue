<template>
    <div >
      
      <el-container>
  
        <el-header class="el-header">植物信息管理系统 
              <el-dropdown >
              <i class="el-icon-setting" style="margin-right: 15px"></i>
              <el-dropdown-menu slot="dropdown" :router="true">
                <el-dropdown-item >
                  <router-link  :to="{ path: '/adminIndex/personDetail', query: {id}}">详情</router-link>
                </el-dropdown-item>
  
                <el-dropdown-item >
                  <router-link  :to="{ path: '/adminIndex/ModifyDetail', query: {id}}">修改</router-link>
                </el-dropdown-item>
  
                <el-dropdown-item >
                  <router-link  to="/">退出登录</router-link>
                </el-dropdown-item>
  
              </el-dropdown-menu>
              </el-dropdown>
          <span style="margin-right:100px;">{{username}}</span>
  
  
        </el-header>
  
  
      <el-container>
  
        <el-aside width="200px" style="background-color: rgb(238, 241, 246)">
            <el-menu :default-openeds="['1', '4']" :router="true">
                <el-submenu index="1">
              <template slot="title"><i class="el-icon-message"></i>导航栏</template>
                <el-menu-item :index="{ path: '/MonitorIndex/ToolOne', query: {username}}">设备一</el-menu-item>
                <el-menu-item :index="{ path: '/MonitorIndex/ToolTwo', query: {username}}">设备二</el-menu-item>
                <el-menu-item :index="{ path: '/MonitorIndex/ToolThird', query: {username}}">设备三</el-menu-item>
                <el-menu-item :index="{ path: '/MonitorIndex/Viewdisease', query: {username}}">病虫害记录管理</el-menu-item>
                </el-submenu>
           </el-menu>
        </el-aside>
        
              
  
          
  
  
  
        <el-main>
          <!-- 1步 -->
         <!-- 定义路由名称 -->
          <router-view name="Monitor"> </router-view>
          
        </el-main>
  
  
  
        </el-container>
      </el-container>
    </div>
  </template>
  
  
  <script>
  export default {
    data() {
      return{
        id:'',
        username:''
      }
    },
    mounted(){
      this.id=this.$route.query.id
      this.username=this.$route.query.username
      // //一进入管理员界面，修改用户最后登陆时间
      // axios.put("http://localhost:2009/users/changelasttime/"+this.$route.query.id).then((result)=>{
      //     this.$message.success("您已成功登录")
      // })
  
    },
    methods:{
      onsubmit:function(){
        
      },
      
  
    }
  }
  </script>
  
  
  
  
  <style>
  #app {
    font-family: Avenir, Helvetica, Arial, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    text-align: center;
    color: #2c3e50;
  }
  
  nav {
    padding: 30px;
  }
  
  nav a {
    font-weight: bold;
    color: #2c3e50;
  }
  
  nav a.router-link-exact-active {
    color: #42b983;
  }
  .el-header {
    background-color: rgb(172, 192, 207);
    color: #131313;
    line-height: 60px;
    text-align: right; 
    font-size: 15px;
  }
  
  </style>
  
  