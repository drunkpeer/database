<template>
    <div class="body">
        <el-form :rules="rules" ref="account" :model="account" class="loginContainer">
            <h3 class="loginTitle">
            重置密码
            </h3>
            <el-form-item prop="password">
                <el-input type="text" v-model="account.password" placeholder="亲，请输入新密码" >
                </el-input>
            </el-form-item>

            <el-button type="primary" style="width:100%" @click="submitLogin">提交</el-button>
            
        </el-form>
    </div>
</template>

<script>
import axios from 'axios';
export default {
    
    data(){
      return{
        
          account:{
              username:"",
              password:"",
              realname:'',
              phone:'',
              qq:'',
              home:'',
              code:''//验证码
          },

          
          rules:{
              password: [
                {required:true,message:"请输入用户名",trigger:"blur"},
                { min: 3, max: 14, message: '长度在 3 到 14 个字符', trigger: 'blur' }],
              
            }
      }
  },
    methods:{
      submitLogin(){
            
          this.$refs.account.validate((valid) => {
              if (valid) {
                this.account.username = this.$route.query.username
                console.log(this.account.username)
                axios.put("http://localhost:2009/users/changePassword",this.account).then((result)=>{
                  
                if(result.data.flag&&result.data.message!=null){//说明修改成功
                    this.$message.error(result.data.message)  
                    
                }else{
                    this.$message.success("修改成功")   
                }
              
                })

                } else {//验证前端检验规则
                  this.$message.error('请重新输入');
                  return false;
              }
          });
      },
      
      mounted(){
        
        },
      
    }
};
</script>


<style lang="less" scoped>
    .loginContainer{
        border-radius: 15px;
        background-clip: padding-box;
        text-align: left;
        margin: auto;
        margin-top: 180px;
        width: 350px;
        padding: 15px 35px 15px 35px;
        background: aliceblue;
        border:1px solid blueviolet;
        box-shadow: 0 0 25px #f885ff;
    }
    .loginTitle{
        margin: 0px auto 48px auto;
        text-align: center;
        font-size: 40px;
    }
    
    .body{
        width: 100vw;
        height: 100vh;
        background-image: url('https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg') ;
        background-size:100%;
       overflow: hidden;
    }
</style>
