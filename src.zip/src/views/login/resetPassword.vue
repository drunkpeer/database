<template>
    <div class="body">
        <el-form :rules="rules" ref="account" :model="account" class="loginContainer">
            <h3 class="loginTitle">
            重置密码
            </h3>
            <el-form-item prop="username">
                <el-input type="text" v-model="account.username" placeholder="亲，请输入用户名" >
                </el-input>
            </el-form-item>

            <el-form-item prop="qq">
                <el-input type="qq" v-model="account.qq" placeholder="亲，请输入邮箱" >
                </el-input>
            </el-form-item>

            <el-form-item prop="code">
                <el-input type="code" v-model="account.code" placeholder="亲，请输入您收到的验证码" >
                </el-input>
            </el-form-item>

            <el-button type="primary" style="width:100%" @click="submitLogin">发送验证码</el-button>
            <el-typography type="body" style="margin-right: 50px;"> 请输入验证码之后点击</el-typography>
            <el-button type="success"  style="margin-top: 10px;" @click="reset">开始重置密码</el-button>
        </el-form>
    </div>
</template>

<script>
import axios from 'axios';
export default {
    
    data(){
      return{
        
          account:{
              username:"",
              password:"",
              realname:'',
              phone:'',
              qq:'',
              home:'',
              code:''//验证码
          },

          
          rules:{
              username: [
                {required:true,message:"请输入用户名",trigger:"blur"},
                { min: 3, max: 14, message: '长度在 3 到 14 个字符', trigger: 'blur' }],
              qq: [
                {required:true, message:"请输入邮箱", trigger:"blur"},
                { min: 2,  message: '邮箱长度要大于2', trigger: 'blur' }],
              
            }
      }
  },
    methods:{
      submitLogin(){
          this.$refs.account.validate((valid) => {
              if (valid) {
                
                axios.get("http://localhost:2009/mail/sendTextMail/"+this.account.qq).then((result)=>{
                  console.log(result.data.flag)
                  console.log(result.data.message)
                if(result.data.flag&&result.data.message=="邮箱格式不正确"){//说明手机已经收到验证码
                  
                    this.$message.error("邮箱格式不正确")   
                }else if(result.data.flag&&result.data.message!=null){
                    this.$message.success("请输入验证码")
                }
              
                })

                } else {//验证前端检验规则
                  this.$message.error('请重新输入用户名');
                  return false;
              }
          });
      },
      reset(){
                axios.get("http://localhost:2009/mail/reset/"+this.account.code).then((result)=>{
                        if(result.data.flag&&result.data.message!=null){//说明验证码错误
                            this.$message.error("验证码错误")   
                        }else if(result.data.flag&&result.data.message==null){
                            this.$message.success("请开始重置密码")
                            //跳转到重置密码的界面
                            
                            this.$router.push({
                              path: "/newPassword",
                              query: {
                              username: this.account.username
                              }
                              });

                        }else{
                          this.$message.error("服务器故障，请稍后再试")
                        }
                      
                })
      }
    }
};
</script>


<style lang="less" scoped>
    .loginContainer{
        border-radius: 15px;
        background-clip: padding-box;
        text-align: left;
        margin: auto;
        margin-top: 180px;
        width: 350px;
        padding: 15px 35px 15px 35px;
        background: aliceblue;
        border:1px solid blueviolet;
        box-shadow: 0 0 25px #f885ff;
    }
    .loginTitle{
        margin: 0px auto 48px auto;
        text-align: center;
        font-size: 40px;
    }
    
    .body{
        width: 100vw;
        height: 100vh;
        background-image: url('https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg') ;
        background-size:100%;
       overflow: hidden;
    }
</style>
