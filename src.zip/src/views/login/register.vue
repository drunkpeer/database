<template>
    <div class="body">
        <el-form :rules="rules" ref="account" :model="account" class="loginContainer">
            <h3 class="loginTitle">
            欢迎注册
            </h3>
            <el-form-item prop="username">
                <el-input type="text" v-model="account.username" placeholder="亲，请输入用户名" >
                </el-input>
            </el-form-item>

            <el-form-item prop="password">
                <el-input type="password" v-model="account.password" placeholder="亲，请输入密码" >
                </el-input>
            </el-form-item>

            <el-form-item prop="realname">
                <el-input type="text" v-model="account.realname" placeholder="亲，请输入真实姓名" >
                </el-input>
            </el-form-item>

            <el-form-item prop="phone">
                <el-input type="text" v-model="account.phone" placeholder="亲，请输入联系方式" >
                </el-input>
            </el-form-item>

            <el-form-item prop="qq">
                <el-input type="text" v-model="account.qq" placeholder="亲，请输入邮箱" >
                </el-input>
            </el-form-item>

            <el-form-item prop="home">
                <el-input type="text" v-model="account.home" placeholder="亲，请输入住址" >
                </el-input>
            </el-form-item>

        
            <el-button type="primary" style="width:100%" @click="submitLogin">注册</el-button>
        </el-form>
    </div>
</template>

<script>
import axios from 'axios';
export default {
    
    data(){
      return{
        
          account:{
              username:"",
              password:"",
              realname:'',
              phone:'',
              qq:'',
              home:''
          },

          
          rules:{
              username: [
                {required:true,message:"请输入用户名",trigger:"blur"},
                { min: 3, max: 14, message: '长度在 3 到 14 个字符', trigger: 'blur' }],
              password: [
                {required:true, message:"请输入密码", trigger:"blur"},
                { min: 2,  message: '密码长度要大于2', trigger: 'blur' }],
              realname: [
                {required:true, message:"请输入真实姓名", trigger:"blur"},
                { min: 2,  message: '真实姓名长度要大于2', trigger: 'blur' }],
              phone: [
                {required:true, message:"请输入联系电话", trigger:"blur"},
                { min: 2,  message: '联系电话长度要大于2', trigger: 'blur' }],  
              qq: [
                {required:true, message:"请输入邮箱", trigger:"blur"},
                { min: 2,  message: '邮箱长度要大于2', trigger: 'blur' }],
              home: [
                {required:true, message:"请输入住址", trigger:"blur"},
                { min: 2,  message: '住址长度要大于2', trigger: 'blur' }],  
            }
      }
  },
    methods:{
      submitLogin(){
          this.$refs.account.validate((valid) => {
              if (valid) {
                //报错的时候，一定要想想自己的返回值是什么，怎么处理，怎么接收
                axios.post("http://localhost:2009/users/reader",this.account).then((result)=>{
                if(result.data.flag&&result.data.meaasge==null){//说明注册成功
                    this.$message.success("注册成功")     
                    //跳转到登陆界面
                    this.$router.push({
                        path:'/'
                        })
                }else if (result.data.flag&&result.data.message!=null) {
                  this.$message.error(result.data.message)//报出注册错误
                }else{
                  this.$message.error("服务器异常，查询失败")
                }
                })

                } else {//验证前端检验规则
                  this.$message.error('登录出错请重新输入');
                  return false;
              }
          });
      }
    }
};
</script>


<style lang="less" scoped>
    .loginContainer{
        border-radius: 15px;
        background-clip: padding-box;
        text-align: left;
        margin: auto;
        margin-top: 120px;
        width: 350px;
        padding: 15px 35px 15px 35px;
        background: aliceblue;
        border:1px solid blueviolet;
        box-shadow: 0 0 25px #f885ff;
    }
    .loginTitle{
        margin: 0px auto 48px auto;
        text-align: center;
        font-size: 40px;
    }
    
    .body{
        width: 100vw;
        height: 100vh;
        background-image: url('https://cube.elemecdn.com/6/94/4d3ea53c084bad6931a56d5158a48jpeg.jpeg') ;
        background-size:100%;
       overflow: hidden;
    }
</style>
