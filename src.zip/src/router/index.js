import Vue from 'vue'
import VueRouter from 'vue-router'

const originalPush = VueRouter.prototype.push 
VueRouter.prototype.push = function push (location) { return originalPush.call(this, location).catch(err => err) }

Vue.use(VueRouter)

const routes = [
  {//登陆界面 --- 正在启用
    path: '/',
    name: 'logIn',
    component: () => import('../views/login/logIn.vue')
  },
  {//监测人员界面 -------------------正在启用
    path: '/MonitorIndex',
    name: 'index',
    component: () => import('../views/MonitorEmployee/MonitorIndex.vue'),
    children:[
      {//设备1
        path : 'ToolOne',
        components : {
          Monitor :()=> import('../components/monitorContext/ToolOne.vue')
        }
      },
      {//设备2
        path: 'ToolTwo',
        components:{
          Monitor:()=>import('../components/monitorContext/ToolTwo.vue')
        }
      },
      {//设备3
        path : 'ToolThird',
        components : {
          Monitor :()=> import('../components/monitorContext/ToolThird.vue')
        }
      },
      {//查看管理所有已知的病虫害表
        path : 'Viewdisease',
        components : {
          Monitor :()=> import('../components/monitorContext/ManageDisease.vue')
        }
      },

    ]
  },
  {//养护人员界面  -----正在启用
    path: '/TreatmentIndex',
    name: 'adminindex',
    component: () => import('../views/TreatEmployee/TreatmentIndex.vue'),
    children:[
      
      {//防治表增删改查
        path : 'prevent',
        components : {
          Treatment :()=> import('../components/TreatContext/ManagePrevent.vue')
        }
      },
      {//点击养护表
        path : 'manageTreatment',
        components : {
          Treatment :()=> import('../components/TreatContext/ManageTreat.vue')
        }
      },
    ]
    },
        {//管理人员界面.............正在启用
          path: '/adminIndex',
          name: 'readerindex',
          component: () => import('../views/admin/adminIndex.vue'),
          children:[
            {//所有植物进行管理的界面
              path : 'plant',
              components : {
                admin :()=> import('../components/adminContext/plant.vue')
              }
            },
            {//分类的界面
              path : 'classification',
              components : {
                admin :()=> import('../components/adminContext/classification.vue')
              }
            },
            {//需要养护的植物页面
              path : 'treat',
              components : {
                admin :()=> import('../components/adminContext/treat.vue')
              }
            },
            {//需要养护的植物页面
              path : 'Addplant',
              components : {
                admin :()=> import('../components/adminContext/Addplant.vue')
              }
            },
            {//根据省市区查找他们所遭受的病虫害
              path : 'PestByArea',
              components : {
                admin :()=> import('../components/adminContext/union/PestByArea.vue')
              }
            },
            {//根据植物种名查找植物所有的信息
              path : 'AllBySpecies_name',
              components : {
                admin :()=> import('../components/adminContext/union/AllBySpecies_name.vue')
              }
            },
            
          ]
        }
        ,
        {//上级管理人员界面.............正在启用
          path: '/departmentIndex',
          name: 'departmentIndex',
          component: () => import('../views/SuperDepartment/departmentIndex.vue'),
          children:[
            {//查看所有养护表的界面
              path : 'treat',
              components : {
                department :()=> import('../components/SuperContext/SuperTreatment.vue')
              }
            },
            {//查看所有监控表的界面
              path : 'monitor',
              components : {
                department :()=> import('../components/SuperContext/SuperMonitor.vue')
              }
            },
            {//查看所有工作人员的界面
              path : 'employee',
              components : {
                department :()=> import('../components/SuperContext/SuperEmployee.vue')
              }
            },
            {//通过养护人查找使用过的所有试剂
              path : 'drugByTreatpeople',
              components : {
                department :()=> import('../components/SuperContext/union/drugByTreatpeople.vue')
              }
            },
            {//通过监测人员查要使用的所有设备
              path : 'equipmentByMonitorpeople',
              components : {
                department :()=> import('../components/SuperContext/union/equipmentByMonitorpeople.vue')
              }
            },
            {//根据种名查找过往治疗记录
              path : 'treatByspecies_name',
              components : {
                department :()=> import('../components/SuperContext/union/TreatByspecies_name.vue')
              }
            },
            
          ]
        }
  

]

const router = new VueRouter({
  routes
})

export default router