<template>
    <div>

        <el-main>
<!-- CREATE TABLE PlantTable (
  plant_id VARCHAR(50) PRIMARY KEY,-- 植物id
  species_name VARCHAR(100), -- 种名
  disease_name VARCHAR(100) DEFAULT '无', -- 病名 创建的时候默认是无
  equipment_name VARCHAR(100), -- 设备名称
		
  -- 下面是没多大用的
  image_id VARCHAR(50), -- 配图编号
  morphology VARCHAR(255), -- 形态特征   整体只展示到这里


  cultivation_techniques VARCHAR(255), -- 栽培技术要点
  application_value VARCHAR(255),-- 应用价值
  create_people VARCHAR(100), -- 创建人
  create_time DATETIME-- 创建时间
); -- 共有十项信息 -->

<!-- 列表呈现表格-- -->
<el-table :data="tableData">
    <el-table-column prop="plant_id" label="植物id" width="100"></el-table-column>
    <el-table-column prop="species_name" label="种名" width="150"></el-table-column>
    <el-table-column prop="disease_name" label="病名" width="150"></el-table-column>
    <el-table-column prop="equipment_name" label="设备" width="150"></el-table-column>

    <el-table-column prop="image_id" label="配图编号" width="150"></el-table-column>
    <el-table-column prop="morphology" label="形态特征" width="100"></el-table-column>

    <el-table-column  label="操作">
    <!-- 将这行对象封装成scope，scope.row指的是这一行的数据-->
    <template slot-scope="scope">
            <el-button type="primary" width="50" @click="handleUpdate(scope.row)">监测</el-button>
    </template>

    </el-table-column>

</el-table>


</el-main>

<!-- CREATE TABLE MonitorTable (
  monitor_id INT AUTO_INCREMENT PRIMARY KEY,-- 主键为int类型，且是自增
  plant_id VARCHAR(100),-- 监测对象，对应植物id
  monitor_people VARCHAR(100), -- 监测人  
  ph INT , -- 默认1到14,不包含小数
  temperature INT ,-- 默认是整数
  
  -- 下面没用
  monitor_time DATETIME, -- 检测时间
  monitor_location VARCHAR(100), -- 检测地点
); -->

<!-- 显示监测表单 -->
<el-dialog title="监测信息" :visible.sync="EditFormVisible">
        <el-form :model="formData" :rules="rules">


            <el-form-item label="植物疾病" :label-width="formLabelWidth">
            <el-input v-model="formData.disease_name" auto-complete="off"></el-input>
            </el-form-item>

            <el-form-item label="ph数值" :label-width="formLabelWidth">
            <el-input v-model="formData.ph" auto-complete="off"></el-input>
            </el-form-item>

            <el-form-item label="温度" :label-width="formLabelWidth">
            <el-input v-model="formData.temperature" auto-complete="off"></el-input>
            </el-form-item>
        </el-form>

        <span slot="footer" class="dialog-footer">
            <el-button @click="cancel">关闭</el-button>
            <el-button type="primary" @click="handleEdit">提交</el-button>
        </span>

</el-dialog>


    </div>

</template>


<script>
import axios from 'axios';
export default{
    data(){
        return{

           
            tableData:[],//列表显示
            

            EditFormVisible: false,//编辑表单是否出现


            formData: {},


            formLabelWidth: '200px',

            rules:{
              username: [{ required: true, message: '用户名为必填项', trigger: 'blur' }],
              password: [{ required: true, message: '密码为必填项', trigger: 'blur' }]
            },

            
            
        }
        
    },

    


    // 进入页面之后的初始化操作，获取员工数据
    mounted(){
      //执行查询
      console.log(1111)
        this.getAll();
    },


    methods:{

        //初始化所有值
        getAll() {
            //发送异步请求
            //初始化该设备表
            axios.get("http://localhost:2009/plants/equipmentOne").then((result)=>{
                this.tableData=result.data.object

            });
        },

          //监测
          //第一步，打开表单获取值
          handleUpdate:function(row){
            this.EditFormVisible = true;
            this.formData.plant_id = row.plant_id
            this.formData.monitor_people = this.$route.query.username

          },

          //第二步，提交表单
          handleEdit:function(){
            this.EditFormVisible = false;
            //总共包括两步走
            // 第一步：修改监测表，增加一条记录
            // 第二步：修改用户表里面植物的病记录


            axios.post("http://localhost:2009/monitors",this.formData).then((res)=>{
                    if(res.data.flag){
                          this.$message.success("修改成功");
                    }else{
                          this.$message.error("修改失败");
                    }
                  }).finally(()=>{
                    //2.重新加载数据
                    this.getAll();
            });  

            axios.put("http://localhost:2009/plants/disease_name",this.formData).then((res)=>{
                    if(res.data.flag){
                          this.$message.success("修改成功");
                    }else{
                          this.$message.error("修改失败");
                    }
                  }).finally(()=>{
                    //2.重新加载数据
                    this.getAll();
            }); 

          }


      
    }

}
</script>

<style>
