<template>
    <div>

        <el-main>

<!-- 表单 -->
<el-form :inline="true" :model="searchForm" class="demo-form-inline">

    <el-form-item label="植物种名称">
      <el-input v-model="searchForm.department_name" placeholder="请填写植物名称"></el-input>
    </el-form-item> 

    <el-form-item>
      <el-button type="primary" @click="query">查询</el-button>
    </el-form-item>

</el-form>



<!-- CREATE TABLE TreatmentTable (
  treat_id INT AUTO_INCREMENT PRIMARY KEY, -- 养护id 主键为int类型，且是自增
  disease_name VARCHAR(100), -- 病名 对应报告书里的的任务名 ------来自管理人员
  prevent_method VARCHAR(255),-- 防治措施 对应报告书里的的任务描述
  plant_id VARCHAR(100),-- 养护对象，对应植物编号 ------来自管理人员
  treat_people VARCHAR(100),-- 对应的养护人 由管理人员选择
  treat_state VARCHAR(100),-- 治疗状态，分为未治疗 和已经治疗
-- 下面是没多大用的
  treat_time DATE, -- 养护时间
  create_time DATETIME -- 创建时间
);

); -->

<!-- 列表呈现表格-- -->
<el-table :data="tableData">
    <el-table-column prop="treat_id" label="养护id" width="100"></el-table-column>
    <el-table-column prop="disease_name" label="病名" width="150"></el-table-column>
    <el-table-column prop="prevent_method" label="防治方法" width="150"></el-table-column>
    <el-table-column prop="plant_id" label="植物id" width="150"></el-table-column>

    <el-table-column prop="treat_people" label="养护人" width="150"></el-table-column>
    <el-table-column prop="treat_state" label="养护状态" width="100"></el-table-column>

    <el-table-column  label="操作">
    <!-- 将这行对象封装成scope，scope.row指的是这一行的数据-->
    <template slot-scope="scope">

            <el-button type="success" width="50" @click="handleUpdate(scope.row)">养护</el-button>

    </template>

    </el-table-column>

</el-table>


</el-main>


<!-- CREATE TABLE TreatmentTable (
  treat_id INT AUTO_INCREMENT PRIMARY KEY, -- 养护id 主键为int类型，且是自增
  disease_name VARCHAR(100), -- 病名 对应报告书里的的任务名
  prevent_method VARCHAR(255),-- 防治措施 对应报告书里的的任务描述
  plant_id VARCHAR(100),-- 养护对象，对应植物编号
  treat_people VARCHAR(100),-- 对应的养护人 由管理人员选择
  treat_state VARCHAR(100),-- 治疗状态，分为未治疗 和已经治疗
-- 下面是没多大用的
  treat_time DATE, -- 养护时间
  create_time DATETIME -- 创建时间
); -->


<!-- 显示防治表单 -->
<el-dialog title="选择防治方法" :visible.sync="EditFormVisible">
        <el-form :model="formData" :rules="rules">

            <el-form-item label="防治方法" :label-width="formLabelWidth">
                <el-select v-model="formData.prevent_method">
                        <el-option :key="item" :label="item" :value="item" v-for="item in prevent_methods"></el-option>
                </el-select>
            </el-form-item>

        </el-form>

        <span slot="footer" class="dialog-footer">
            <el-button @click="cancel">关闭</el-button>
            <el-button type="primary" @click="handleEdit">提交</el-button>
        </span>

</el-dialog>



    </div>

</template>


<script>
import axios from 'axios';
export default{
    data(){
        return{

           
            tableData:[],//列表显示
            

            //查询表单
            searchForm: {
              param:'',
              department_name:''
            },


            EditFormVisible: false,//编辑表单是否出现
            prevent_methods:[],



            formData: {
                
            },


            formLabelWidth: '200px',

            rules:{
              username: [{ required: true, message: '用户名为必填项', trigger: 'blur' }],
              password: [{ required: true, message: '密码为必填项', trigger: 'blur' }]
            },

            
            
        }
        
    },

    


    // 进入页面之后的初始化操作，获取员工数据
    mounted(){
      //执行查询
      console.log(1111)
        this.getAll();
    },


    methods:{

        //初始化所有值
        getAll() {
            //初始化养护列表
            axios.get("http://localhost:2009/treatments/disease/"+this.$route.query.username).then((result)=>{
                this.tableData=result.data.object

            });

            //用于查询所有的防治方法
            axios.get("http://localhost:2009/prevents/names").then((result)=>{
                this.prevent_methods=result.data.object

            });
        },


          //关闭详情页
          cancel() {
              this.dialogFormVisible=false  
              this.EditFormVisible=false  
          },


          //养护方法
          //第一步，打开表单获取值
          handleUpdate:function(row){
            this.EditFormVisible = true;
            this.formData.treat_id = row.treat_id
            this.formData.plant_id=row.plant_id
          },

          //第二步，选择养护方法之后点击养护的时候
        //   1.将该植物基本信息的病名改为无，第二步:将该植物的状态改为已治疗
          handleEdit:function(){
            this.EditFormVisible = false;

            //将植物基本信息表里的病名改为无
            axios.put("http://localhost:2009/plants/"+this.formData.plant_id).then((res)=>{
                    if(res.data.flag){
                       
                            this.$message.success("更新成功");
                    }else{
                            this.$message.error("编更新失败");
                    }
             })

            
            axios.put("http://localhost:2009/treatments/prevent_methods",this.formData).then((res)=>{
                    if(res.data.flag){
                          this.$message.success("修改成功");
                    }else{
                          this.$message.error("修改失败");
                    }
                  }).finally(()=>{
                    //2.重新加载数据
                    this.getAll();
            });  


          }


      
    }

}
</script>

<style>