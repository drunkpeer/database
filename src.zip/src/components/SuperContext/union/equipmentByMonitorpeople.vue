<template>
    <div>

        <el-main>


            <!-- 表单 -->
<el-form :inline="true" :model="searchForm" class="demo-form-inline">

<el-form-item label="监测人名称">
  <el-input v-model="searchForm.monitor_people" placeholder="请填写监测人的名称"></el-input>
</el-form-item> 

<el-form-item>
  <el-button type="primary" @click="query">查询</el-button>
</el-form-item>

</el-form>

            <!-- @Data
public class DrugByTreatPeople {
    String treat_people;
    String species_name;
    String disease_name;
    String drug_name;
    String drug_amount;

} -->




<!-- 列表呈现表格-- -->
    <el-table :data="tableData">
        <el-table-column prop="monitor_people" label="监测人" width="100"></el-table-column>
        <el-table-column prop="species_name" label="种名" width="150"></el-table-column>
        <el-table-column prop="equipment_name" label="设备名" width="150"></el-table-column>
  

    </el-table>

</el-main>


    </div>

</template>


<script>
import axios from 'axios';
export default{
    data(){
        return{

           
            tableData:[],//列表显示
            
        
            searchForm:{

            },


            formLabelWidth: '200px',

            rules:{
              username: [{ required: true, message: '用户名为必填项', trigger: 'blur' }],
              password: [{ required: true, message: '密码为必填项', trigger: 'blur' }]
            },

            
        }
        
    },

    


    // 进入页面之后的初始化操作，获取员工数据
    mounted(){
      //执行查询
      console.log(1111)
        this.getAll();
    },


    methods:{

        //初始化所有值
        getAll() {
            //初始化养护列表，查询所有养护人使用过的药物名称
            axios.get("http://localhost:2009/unions/equipmentByMonitorpeople").then((result)=>{
                this.tableData=result.data.object
            });   
        },
        query(){
            //根据养护人名查询信息
        
            axios.get("http://localhost:2009/unions/equipmentByMonitorpeople/"+this.searchForm.monitor_people).then((result)=>{
                this.tableData=result.data.object
            });
        }






          


      
    }

}
</script>

<style>