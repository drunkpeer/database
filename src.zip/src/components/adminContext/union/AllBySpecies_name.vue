<template>
    <div>

        <el-main>


            <!-- 搜索表单 -->
<el-form :inline="true" :model="searchForm" class="demo-form-inline">

<el-form-item label="种名">
  <el-input v-model="searchForm.species_name" placeholder="请填写种名"></el-input>
</el-form-item> 

<el-form-item>
  <el-button type="primary" @click="query">查询</el-button>
</el-form-item>

</el-form>

            <!-- @Data
distributiontable.province AS province,
       distributiontable.city AS city,
       distributiontable.town AS town,
       classificationtable.species_name AS species_name,
       planttable.disease_name AS disease_name 
} -->

<!-- 列表呈现表格-- -->
    <el-table :data="tableData">
        <el-table-column prop="species_name" label="种名" width="150"></el-table-column>
        <el-table-column prop="family_name " label="科名" width="150"></el-table-column>
        <el-table-column prop="genus_name " label="属名" width="150"></el-table-column>
        <el-table-column prop="province" label="省" width="150"></el-table-column>
        <el-table-column prop="city" label="市" width="150"></el-table-column>
        <el-table-column prop="town" label="县" width="150"></el-table-column>
        

    </el-table>

</el-main>


    </div>

</template>


<script>
import axios from 'axios';
export default{
    data(){
        return{

           
            tableData:[],//列表显示
            
        
            searchForm:{

            },


            formLabelWidth: '200px',

            rules:{
              username: [{ required: true, message: '用户名为必填项', trigger: 'blur' }],
              password: [{ required: true, message: '密码为必填项', trigger: 'blur' }]
            },

            
        }
        
    },

    


    // 进入页面之后的初始化操作，获取员工数据
    mounted(){
      //执行查询
      console.log(1111)
        this.getAll();
    },


    methods:{

        //初始化所有值
        getAll() {
            //初始化养护列表，查询所有养护人使用过的药物名称
            axios.get("http://localhost:2009/unions/detail").then((result)=>{
                this.tableData=result.data.object
            });   
        },
        query(){
            //根据养护人名查询信息
        
            axios.get("http://localhost:2009/unions/detail/"+this.searchForm.species_name).then((result)=>{
                this.tableData=result.data.object
            });
        }






          


      
    }

}
</script>

<style>