<template>
    <div>

        <el-main>

<!-- 表单 -->
<el-form :inline="true" :model="searchForm" class="demo-form-inline">

    <el-form-item label="植物科名">
      <el-input v-model="searchForm.family_name" placeholder="请填写植物名称"></el-input>
    </el-form-item> 
    <el-form-item label="植物属名">
      <el-input v-model="searchForm.genus_name" placeholder="请填写植物属名"></el-input>
    </el-form-item> 

    <el-form-item>
      <el-button type="primary" @click="query">查询</el-button>
    </el-form-item>

</el-form>



<!-- public class Classification {
    int classification_id;
    String family_name;
    String genus_name;
    String species_name;
    String alias;
    String distribution_id;
    String growth_environment;

} -->

<!-- 列表呈现表格-- -->
<el-table :data="tableData">
    <el-table-column prop="classification_id" label="分类id" width="100"></el-table-column>
    <el-table-column prop="family_name" label="科名" width="150"></el-table-column>
    <el-table-column prop="genus_name" label="属名" width="150"></el-table-column>
    <el-table-column prop="species_name" label="种名" width="150"></el-table-column>
    <el-table-column prop="alias" label="别名" width="150"></el-table-column>
    <el-table-column prop="distribution_id" label="分布地点id" width="100"></el-table-column>
    <el-table-column prop="growth_environment" label="生长环境" width="100"></el-table-column>

    <el-table-column  label="操作">
    <!-- 将这行对象封装成scope，scope.row指的是这一行的数据-->
    <template slot-scope="scope">
            <el-button type="success" width="50" @click="handleEnvironment(scope.row)">分布地点</el-button>
            <el-button type="success" width="50" @click="handleUpdate(scope.row)">编辑</el-button>
            <el-button type="danger" width="50" @click="handleDelete(scope.row)">删除</el-button>
    </template>

    </el-table-column>

</el-table>


</el-main>

<!-- 显示分布地点表单 -->
<el-dialog title="分布地点" :visible.sync="EnvironmentVisible">

<el-form :model="EnvironmentData" :rules="rules">

    <el-form-item label="省" :label-width="formLabelWidth" prop="username">
      <el-input v-model="EnvironmentData.province" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="市" :label-width="formLabelWidth"  prop="password">
      <el-input v-model="EnvironmentData.city" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="县" :label-width="formLabelWidth">
      <el-input v-model="EnvironmentData.town" auto-complete="off"></el-input>
    </el-form-item>

    
</el-form>

<span slot="footer" class="dialog-footer">
<el-button @click="cancel">关闭</el-button>
</span>

</el-dialog>


<!-- 显示编辑表单 -->
<el-dialog title="编辑" :visible.sync="EditFormVisible">
        <el-form :model="formData" :rules="rules">


            <el-form-item label="种名" :label-width="formLabelWidth">
            <el-input v-model="formData.species_name" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="病名" :label-width="formLabelWidth">
            <el-input v-model="formData.disease_name" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="设备" :label-width="formLabelWidth">
            <el-input v-model="formData.equipment_name" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="配图编号" :label-width="formLabelWidth">
            <el-input v-model="formData.image_id" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="形态特征" :label-width="formLabelWidth">
            <el-input v-model="formData.morphology" auto-complete="off"></el-input>
            </el-form-item>
            
        </el-form>

        <span slot="footer" class="dialog-footer">
            <el-button @click="cancel">关闭</el-button>
            <el-button type="primary" @click="handleEdit">提交</el-button>
        </span>

</el-dialog>


    </div>

</template>


<script>
import axios from 'axios';
export default{
    data(){
        return{

           
            tableData:[],//列表显示
            

            //查询表单
            searchForm: {
              
            },


            EnvironmentVisible: false,//详情表单是否显现
            EditFormVisible: false,//编辑表单是否出现


            EnvironmentData:{},//显示生长环境表单

            formData: {
              
            },


            formLabelWidth: '200px',

            rules:{
              username: [{ required: true, message: '用户名为必填项', trigger: 'blur' }],
              password: [{ required: true, message: '密码为必填项', trigger: 'blur' }]
            },

            
            
        }
        
    },

    


    // 进入页面之后的初始化操作，获取员工数据
    mounted(){
      //执行查询
        this.getAll();
    },


    methods:{

        //初始化所有值
        getAll() {
            //发送异步请求
            console.log(1111)
            axios.get("http://localhost:2009/classifications").then((result)=>{
                this.tableData=result.data.object

            });
        },


        //模糊查询请求
        query:function(){
          
            //查询请求
            //发送异步请求
            
            axios.post("http://localhost:2009/classifications/query",this.searchForm).then((result)=>{
                
                
                this.tableData=result.data.object

            });
            
        },

    

          //删除操作
          handleDelete:function(row){
              this.$confirm("此操作永久删除，是否继续？" ,"提示",{type:"info"}).then(()=>{
                axios.delete("http://localhost:2009/plants/"+row.plant_id).then((res)=>{
                          if(res.data.flag){
                              
                              this.$message.success("删除成功");
                          }else{
                              this.$message.error("删除失败");
                          }
                      }).finally(()=>{
                        
                          this.getAll();
                      });


              }).catch(()=>{//取消删除操作
                this.$message.error("删除操作取消");
              })  
          },
          
          
          // 显示生长环境的方法
          handleEnvironment:function(row){
            this.EnvironmentVisible = true;
            axios.get("http://localhost:2009/distributions/"+row.distribution_id).then((res)=>{
                    if(res.data.flag){
                              this.EnvironmentData=res.data.object
                              this.$message.success("显示分布地点");
                    }else{
                              this.$message.error(res.data.message);
                    }
                  })
          },

          //关闭详情页
          cancel() {
              this.EnvironmentVisible=false  
              this.EditFormVisible=false  
          },




          //编辑方法
          //第一步，打开表单获取值
          handleUpdate:function(row){
            this.EditFormVisible = true;
            axios.get("http://localhost:2009/plants/"+row.plant_id).then((res)=>{
                    if(res.data.flag){
                            this.formData=res.data.object
                            this.$message.success("开始编辑");
                    }else{
                            this.$message.error("编辑失败");
                    }
                  })

          },

          //第二步，提交表单
          handleEdit:function(){
            this.EditFormVisible = false;

            axios.put("http://localhost:2009/plants",this.formData).then((res)=>{
                    if(res.data.flag){
                          this.$message.success("修改成功");
                    }else{
                          this.$message.error("修改失败");
                    }
                  }).finally(()=>{
                    //2.重新加载数据
                    this.getAll();
                });  
          }


      
    }

}
</script>

<style>
