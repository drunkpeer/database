<template>
    <div>

    
        <el-main>
                    <el-form ref="form" :model="formData" label-width=100px class="narrow-form">
   
                        <el-form-item label="植物编号" prop="username" >
                            <el-input v-model="formData.plant_id" ></el-input>
                        </el-form-item>

                        <el-form-item label="种名" prop="password">
                            <el-input  v-model="formData.species_name"></el-input>
                        </el-form-item>

                        <el-form-item label="病名" prop="realName">
                            <el-input v-model="formData.disease_name"></el-input>
                        </el-form-item>


                        <el-form-item label="设备名称" prop="phone">
                            <el-select v-model="formData.equipment_name">
                                <el-option :key="item" :label="item" :value="item" v-for="item in equipments_options"></el-option>
                            </el-select>
                        </el-form-item>


                        <el-form-item label="配图编号" prop="qq">
                            <el-input v-model="formData.image_id"></el-input>
                        </el-form-item>

                            
                        <el-form-item label="形态特征" prop="home">
                            <el-input v-model="formData.morphology"></el-input>
                        </el-form-item>

                        

                        <el-form-item>
                            <el-button type="primary" @click="submitForm">提交</el-button>
                        </el-form-item>

                    </el-form>  
                </el-main>

    </div>
</template>

<script>
import axios from 'axios';
export default {
  data() {
    return {
      formData: {//注明：lasttime和createtime和is_register不需要在这里指定 createtime在后端接收后利用set指定即可
        disease_name:'无',
        create_people:'管理人员'
      },
      //表单部门选择项
      equipments_options:[
        
      ],
      
    };
  },
  mounted(){
        //为了拿到设备名称
        axios.get("http://localhost:2009/equipments/names").then((result)=>{
          // console.log(result.data.object);
          this.equipments_options = result.data.object

        })

     },
  methods: {

     //添加新用户的方法
    submitForm() {
      axios.post("http://localhost:2009/plants",this.formData).then((result)=>{
          if(result.data.flag){
             this.$message.success("添加成功")
          }else{
             this.$message.error("添加失败")
          }
        })
     }

  }
};
</script>




<style>

.narrow-form{
    margin-right: 400px;
    margin-left: 300px;
  }

</style>
