<template>
    <div>

        <el-main>

<!-- 表单 -->
<el-form :inline="true" :model="searchForm" class="demo-form-inline">

    <el-form-item label="植物种名称">
      <el-input v-model="searchForm.department_name" placeholder="请填写植物名称"></el-input>
    </el-form-item> 

    <el-form-item>
      <el-button type="primary" @click="query">查询</el-button>
    </el-form-item>

</el-form>



<!-- CREATE TABLE PlantTable (
  plant_id VARCHAR(50) PRIMARY KEY,-- 植物id
  species_name VARCHAR(100), -- 种名
  disease_name VARCHAR(100) DEFAULT '无', -- 病名 创建的时候默认是无
  equipment_name VARCHAR(100), -- 设备名称
		
  -- 下面是没多大用的
  image_id VARCHAR(50), -- 配图编号
  morphology VARCHAR(255), -- 形态特征   整体只展示到这里


  cultivation_techniques VARCHAR(255), -- 栽培技术要点
  application_value VARCHAR(255),-- 应用价值
  create_people VARCHAR(100), -- 创建人
  create_time DATETIME-- 创建时间
); -- 共有十项信息 -->

<!-- 列表呈现表格-- -->
<el-table :data="tableData">
    <el-table-column prop="plant_id" label="植物id" width="100"></el-table-column>
    <el-table-column prop="species_name" label="种名" width="150"></el-table-column>
    <el-table-column prop="disease_name" label="病名" width="150"></el-table-column>
    <el-table-column prop="equipment_name" label="设备" width="150"></el-table-column>

    <el-table-column prop="image_id" label="配图编号" width="150"></el-table-column>
    <el-table-column prop="morphology" label="形态特征" width="100"></el-table-column>

    <el-table-column  label="操作">
    <!-- 将这行对象封装成scope，scope.row指的是这一行的数据-->
    <template slot-scope="scope">
            <el-button type="primary" width="50" @click="handleDetail(scope.row)">详情</el-button>
            <el-button type="success" width="50" @click="handleUpdate(scope.row)">编辑</el-button>
            <el-button type="danger" width="50" @click="handleDelete(scope.row)">删除</el-button>
    </template>

    </el-table-column>

</el-table>


</el-main>

<!-- 显示详情表单 -->
<el-dialog title="详情" :visible.sync="dialogFormVisible">

<el-form :model="formData" :rules="rules">

    <el-form-item label="植物id" :label-width="formLabelWidth" prop="username">
      <el-input v-model="formData.plant_id" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="种名" :label-width="formLabelWidth"  prop="password">
      <el-input v-model="formData.species_name" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="病名" :label-width="formLabelWidth">
      <el-input v-model="formData.disease_name" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="设备" :label-width="formLabelWidth">
      <el-input v-model="formData.equipment_name" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="配图编号" :label-width="formLabelWidth">
      <el-input v-model="formData.image_id" auto-complete="off"></el-input>
    </el-form-item>

    <el-form-item label="形态特征" :label-width="formLabelWidth">
      <el-input v-model="formData.morphology" auto-complete="off"></el-input>
    </el-form-item>

</el-form>

<span slot="footer" class="dialog-footer">
<el-button @click="cancel">关闭</el-button>
</span>

</el-dialog>


<!-- 显示编辑表单 -->
<el-dialog title="编辑" :visible.sync="EditFormVisible">
        <el-form :model="formData" :rules="rules">


            <el-form-item label="种名" :label-width="formLabelWidth">
            <el-input v-model="formData.species_name" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="病名" :label-width="formLabelWidth">
            <el-input v-model="formData.disease_name" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="设备" :label-width="formLabelWidth">
            <el-input v-model="formData.equipment_name" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="配图编号" :label-width="formLabelWidth">
            <el-input v-model="formData.image_id" auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="形态特征" :label-width="formLabelWidth">
            <el-input v-model="formData.morphology" auto-complete="off"></el-input>
            </el-form-item>
            
        </el-form>

        <span slot="footer" class="dialog-footer">
            <el-button @click="cancel">关闭</el-button>
            <el-button type="primary" @click="handleEdit">提交</el-button>
        </span>

</el-dialog>


    </div>

</template>


<script>
import axios from 'axios';
export default{
    data(){
        return{

           
            tableData:[],//列表显示
            

            //查询表单
            searchForm: {
              param:'',
              department_name:''
            },


            dialogFormVisible: false,//详情表单是否显现
            EditFormVisible: false,//编辑表单是否出现




            formData: {
              

            },


            formLabelWidth: '200px',

            rules:{
              username: [{ required: true, message: '用户名为必填项', trigger: 'blur' }],
              password: [{ required: true, message: '密码为必填项', trigger: 'blur' }]
            },

            
            
        }
        
    },

    


    // 进入页面之后的初始化操作，获取员工数据
    mounted(){
      //执行查询
      console.log(1111)
        this.getAll();
    },


    methods:{

        //初始化所有值
        getAll() {
            //发送异步请求
            console.log(1111)
            axios.get("http://localhost:2009/plants").then((result)=>{
                this.tableData=result.data.object

            });
        },


        //模糊查询请求
        query:function(){
          
            this.searchForm.param="?department_name="+this.searchForm.department_name;
            console.log("http://localhost:2009/depts"+this.searchForm.param)
            //发送异步请求
            axios.get("http://localhost:2009/depts"+this.searchForm.param).then((result)=>{
                
                console.log(result.data)
                this.tableData=result.data.object

            });
            
        },

    

          //删除操作
          handleDelete:function(row){
              this.$confirm("此操作永久删除，是否继续？" ,"提示",{type:"info"}).then(()=>{
                axios.delete("http://localhost:2009/plants/"+row.plant_id).then((res)=>{
                          if(res.data.flag){
                              
                              this.$message.success("删除成功");
                          }else{
                              this.$message.error("删除失败");
                          }
                      }).finally(()=>{
                        
                          this.getAll();
                      });


              }).catch(()=>{//取消删除操作
                this.$message.error("删除操作取消");
              })  
          },
          
          
          // 显示详情的方法
          handleDetail:function(row){
            this.dialogFormVisible = true;
            axios.get("http://localhost:2009/plants/"+row.plant_id).then((res)=>{
                    if(res.data.flag){
                              this.formData=res.data.object
                              this.$message.success("显示详情");
                    }else{
                              this.$message.error(res.data.message);
                    }
                  })
          },
          //关闭详情页
          cancel() {
              this.dialogFormVisible=false  
              this.EditFormVisible=false  
          },


          //编辑方法
          //第一步，打开表单获取值
          handleUpdate:function(row){
            this.EditFormVisible = true;
            axios.get("http://localhost:2009/plants/"+row.plant_id).then((res)=>{
                    if(res.data.flag){
                            this.formData=res.data.object
                            this.$message.success("开始编辑");
                    }else{
                            this.$message.error("编辑失败");
                    }
                  })

          },

          //第二步，提交表单
          handleEdit:function(){
            this.EditFormVisible = false;

            axios.put("http://localhost:2009/plants",this.formData).then((res)=>{
                    if(res.data.flag){
                          this.$message.success("修改成功");
                    }else{
                          this.$message.error("修改失败");
                    }
                  }).finally(()=>{
                    //2.重新加载数据
                    this.getAll();
                });  
          }


      
    }

}
</script>

<style>
