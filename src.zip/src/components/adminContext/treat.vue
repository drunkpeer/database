<template>
    <div>

        <el-main>

<!-- 表单 -->
<el-form :inline="true" :model="searchForm" class="demo-form-inline">

    <el-form-item label="植物种名称">
      <el-input v-model="searchForm.department_name" placeholder="请填写植物名称"></el-input>
    </el-form-item> 

    <el-form-item>
      <el-button type="primary" @click="query">查询</el-button>
    </el-form-item>

</el-form>



<!-- CREATE TABLE PlantTable (
  plant_id VARCHAR(50) PRIMARY KEY,-- 植物id
  species_name VARCHAR(100), -- 种名
  disease_name VARCHAR(100) DEFAULT '无', -- 病名 创建的时候默认是无
  equipment_name VARCHAR(100), -- 设备名称
		
  -- 下面是没多大用的
  image_id VARCHAR(50), -- 配图编号
  morphology VARCHAR(255), -- 形态特征   整体只展示到这里


  cultivation_techniques VARCHAR(255), -- 栽培技术要点
  application_value VARCHAR(255),-- 应用价值
  create_people VARCHAR(100), -- 创建人
  create_time DATETIME-- 创建时间
); -- 共有十项信息 -->

<!-- 列表呈现表格-- -->
<el-table :data="tableData">
    <el-table-column prop="plant_id" label="植物id" width="100"></el-table-column>
    <el-table-column prop="species_name" label="种名" width="150"></el-table-column>
    <el-table-column prop="disease_name" label="病名" width="150"></el-table-column>
    <el-table-column prop="equipment_name" label="设备" width="150"></el-table-column>

    <el-table-column prop="image_id" label="配图编号" width="150"></el-table-column>
    <el-table-column prop="morphology" label="形态特征" width="100"></el-table-column>

    <el-table-column  label="操作">
    <!-- 将这行对象封装成scope，scope.row指的是这一行的数据-->
    <template slot-scope="scope">

            <el-button type="success" width="50" @click="handleUpdate(scope.row)">养护</el-button>

    </template>

    </el-table-column>

</el-table>


</el-main>


<!-- CREATE TABLE TreatmentTable (
  treat_id INT AUTO_INCREMENT PRIMARY KEY, -- 养护id 主键为int类型，且是自增
  disease_name VARCHAR(100), -- 病名 对应报告书里的的任务名
  prevent_method VARCHAR(255),-- 防治措施 对应报告书里的的任务描述
  plant_id VARCHAR(100),-- 养护对象，对应植物编号
  treat_people VARCHAR(100),-- 对应的养护人 由管理人员选择
  treat_state VARCHAR(100),-- 治疗状态，分为未治疗 和已经治疗
-- 下面是没多大用的
  treat_time DATE, -- 养护时间
  create_time DATETIME -- 创建时间
); -->
<!-- 显示编辑表单 -->
<el-dialog title="分配养护任务" :visible.sync="EditFormVisible">
        <el-form :model="formData" :rules="rules">

            <el-form-item label="养护人" :label-width="formLabelWidth">
            <el-input v-model="submitForm.treat_people" auto-complete="off"></el-input>
            </el-form-item>

        </el-form>

        <span slot="footer" class="dialog-footer">
            <el-button @click="cancel">关闭</el-button>
            <el-button type="primary" @click="handleEdit">提交</el-button>
        </span>

</el-dialog>


    </div>

</template>


<script>
import axios from 'axios';
export default{
    data(){
        return{

           
            tableData:[],//列表显示
            

            //查询表单
            searchForm: {
              param:'',
              department_name:''
            },


            dialogFormVisible: false,//详情表单是否显现
            EditFormVisible: false,//编辑表单是否出现




            formData: {
                
            },

            submitForm:{//最终提交到养护表的表单
                treat_state:'未治疗',
            },


            formLabelWidth: '200px',

            rules:{
              username: [{ required: true, message: '用户名为必填项', trigger: 'blur' }],
              password: [{ required: true, message: '密码为必填项', trigger: 'blur' }]
            },

            
            
        }
        
    },

    


    // 进入页面之后的初始化操作，获取员工数据
    mounted(){
      //执行查询
      console.log(1111)
        this.getAll();
    },


    methods:{

        //初始化所有值
        getAll() {
            //发送异步请求
            console.log(1111)
            axios.get("http://localhost:2009/plants/disease").then((result)=>{
                this.tableData=result.data.object

            });
        },


          //关闭详情页
          cancel() {
              this.dialogFormVisible=false  
              this.EditFormVisible=false  
          },


          //养护方法
          //第一步，打开表单获取值
          handleUpdate:function(row){
            this.EditFormVisible = true;
            this.submitForm.plant_id = row.plant_id 

            axios.get("http://localhost:2009/plants/"+row.plant_id).then((res)=>{
                    if(res.data.flag){
                            this.formData=res.data.object
                            this.submitForm.disease_name = this.formData.disease_name;
                            
            
                            this.$message.success("开始养护");
                    }else{
                            this.$message.error("编辑失败");
                    }
                  })



          },

          //第二步，提交表单
          handleEdit:function(){
            this.EditFormVisible = false;

            
            axios.post("http://localhost:2009/treatments",this.submitForm).then((res)=>{
                    if(res.data.flag){
                          this.$message.success("修改成功");
                    }else{
                          this.$message.error("修改失败");
                    }
                  }).finally(()=>{
                    //2.重新加载数据
                    this.getAll();
                });  
          }


      
    }

}
</script>

<style>
