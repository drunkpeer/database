import Vue from 'vue'
import App from './App.vue'
import router from './router'


import ElementUI from 'element-ui';

import 'element-ui/lib/theme-chalk/index.css';


//引入 echarts
// import echarts from 'echarts'
//注册组件
// Vue.prototype.$echarts = echarts
import * as echarts from "echarts";
Vue.prototype.$echarts = echarts


Vue.config.productionTip = false
Vue.config.devtools = false;


Vue.use(ElementUI);
new Vue({

 router,

 render: h => h(App)

}).$mount('#app')

