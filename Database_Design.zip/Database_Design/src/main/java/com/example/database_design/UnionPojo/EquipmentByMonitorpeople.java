package com.example.database_design.UnionPojo;


import lombok.Data;

//CREATE VIEW equipmentByMonitorpeople AS
//        SELECT monitortable.monitor_people AS monitor_people,
//        planttable.species_name AS species_name,
//        equipmentable.equipment_name AS equipment_name
//        FROM monitortable
//        JOIN planttable ON monitortable.plant_id = planttable.plant_id
//        JOIN equipmentable ON planttable.equipment_name = equipmentable.equipment_name
//
//
//        SELECT * FROM equipmentByMonitorpeople
@Data
public class EquipmentByMonitorpeople {
    String monitor_people;
    String species_name;
    String equipment_name;
}
