package com.example.database_design.Dao.Union;


import com.example.database_design.UnionPojo.EquipmentByMonitorpeople;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface EquipmentByMonitorpeopleDao {



    @Select("SELECT * FROM equipmentByMonitorpeople")
    public List<EquipmentByMonitorpeople> get_all();

    @Select("SELECT * FROM equipmentByMonitorpeople where monitor_people=#{monitor_people}")
    public List<EquipmentByMonitorpeople> get_all_monitor_people(String monitor_people);


}
