package com.example.database_design.pojo;


import lombok.Data;

@Data
public class Equipment {
    String equipment_id;
    String equipment_name;



}
//    CREATE TABLE equipmenTable(
//        equipment_id VARCHAR(20) PRIMARY KEY ,-- 对应设备表
//        equipment_name VARCHAR(20) -- 设备名称
//        )