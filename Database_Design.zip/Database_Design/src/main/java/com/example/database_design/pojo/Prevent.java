package com.example.database_design.pojo;


import lombok.Data;

@Data
public class Prevent {
    int prevent_id;
    String prevent_method;


    String drug_name;
    String drug_amount;
    String prevention_detail;// 具体用法
    String action_period;
}

//    CREATE TABLE preventTable(
//        prevent_id INT AUTO_INCREMENT PRIMARY KEY, -- 防治id 主键为int类型，且是自增
//        prevent_method VARCHAR(100), -- 防治方法 与植物信息表里面的防治方法相对应
//        drug_name VARCHAR(100), -- 药剂名称
//        drug_amount VARCHAR(100), -- 药剂用量
//        prevention_detail VARCHAR(255), -- 具体实施药剂措施 描述
//        action_period VARCHAR(100) -- 作用期限
//        )
