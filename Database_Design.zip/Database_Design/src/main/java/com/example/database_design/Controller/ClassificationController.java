package com.example.database_design.Controller;


import com.example.database_design.Service.ClassificationService.ClassificationService;
import com.example.database_design.Utils.Result;
import com.example.database_design.pojo.Classification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/classifications")
public class ClassificationController {

    @Autowired
    ClassificationService classificationService;


    @GetMapping
    public Result get_all(){
        return new Result(true,classificationService.select_All());
    }

    @GetMapping("/{classification_id}")
    public Result get_One(@PathVariable int classification_id){
        return new Result(true,classificationService.select_One(classification_id));
    }

    @PostMapping("/query")
    public Result get_One(@RequestBody  Classification classification){
        System.out.println("调用了吗");
        System.out.println(classification);
        return new Result(true,classificationService.select_query(classification));
    }






}
