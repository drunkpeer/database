package com.example.database_design;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseDesignApplication {

    public static void main(String[] args) {
        SpringApplication.run(DatabaseDesignApplication.class, args);
    }

}
