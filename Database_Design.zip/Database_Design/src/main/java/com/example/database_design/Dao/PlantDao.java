package com.example.database_design.Dao;


import com.example.database_design.pojo.Plant;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;


//植物基本信息表
@Mapper
@Repository
public interface PlantDao {

    //增加（插入）一个植物信息
    int insert_one(Plant plant);

    //删除一个植物信息
    int delete_by_plant_id(String plant_id);

    //通过植物id  更新（修改）一个植物的所有信息
    int update_by_plant_id(Plant plant);


    //根据植物id更新植物的病名为无
    int update_disease_name(String plant_id);


    //根据植物id更新植物的病名为其他病名
    int update_add_disease(Plant plant);



    //查找所有植物信息
    List<Plant> select_All();

    //查找所有有病名的植物信息
    List<Plant> select_All_desease();

    //查找所有设备是1的植物
    @Select("select * from plantTable where equipment_name= '设备1'  ")
    List<Plant> select_All_equipment_one();

    //查找所有设备是2的植物
    @Select("select * from plantTable where equipment_name= '设备2'  ")
    List<Plant> select_All_equipment_two();

    //查找所有设备是3的植物
    @Select("select * from plantTable where equipment_name= '设备3'  ")
    List<Plant> select_All_equipment_third();



    //查找一个植物的操作
    Plant select_One(String plant_id);


}
