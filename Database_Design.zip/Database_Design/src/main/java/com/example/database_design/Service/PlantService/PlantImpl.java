package com.example.database_design.Service.PlantService;

import com.example.database_design.Dao.PlantDao;
import com.example.database_design.pojo.Plant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class PlantImpl implements PlantService{
    @Autowired
    PlantDao plantDao;

    @Override
    public Boolean add(Plant plant) {
        return plantDao.insert_one(plant)>0;
    }

    @Override
    public Boolean delete_by_plant_id(String plant_id) {
        return plantDao.delete_by_plant_id(plant_id)>0;
    }

    @Override
    public Boolean update_by_plant_id(Plant plant) {
        return plantDao.update_by_plant_id(plant)>0;
    }

    @Override
    public Boolean update_disease_name(String plant_id) {
        return plantDao.update_disease_name(plant_id)>0;
    }

    @Override
    public Boolean update_add_disease(Plant plant) {
        return plantDao.update_add_disease(plant)>0;
    }

    @Override
    public List<Plant> select_All() {
        return plantDao.select_All();
    }

    @Override
    public List<Plant> select_All_disease() {
        return plantDao.select_All_desease();
    }


    @Override
    public List<Plant> select_All_equipment_one() {
        return plantDao.select_All_equipment_one();
    }

    @Override
    public List<Plant> select_All_equipment_two() {
        return plantDao.select_All_equipment_two();
    }

    @Override
    public List<Plant> select_All_equipment_third() {
        return plantDao.select_All_equipment_third();
    }



    @Override
    public Plant select_One(String plant_id) {
        return plantDao.select_One(plant_id);
    }
}
