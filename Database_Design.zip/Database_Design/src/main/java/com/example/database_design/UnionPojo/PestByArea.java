package com.example.database_design.UnionPojo;


//SELECT
//        distributiontable.province AS province,
//        distributiontable.city AS city,
//        distributiontable.town AS town,
//        classificationtable.species_name AS species_name,
//        planttable.disease_name AS disease_name

import lombok.Data;

@Data
public class PestByArea {
    String province;
    String city;
    String town;
    String species_name;
    String disease_name;
}
