package com.example.database_design.Controller;


import com.example.database_design.Service.PlantService.PlantImpl;
import com.example.database_design.Utils.Result;
import com.example.database_design.pojo.Plant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/plants")
public class PlantController {

    @Autowired
    PlantImpl plantImpl;

    //添加操作,JSON数据通过请求体传送过来
    @PostMapping
    public Result save(@RequestBody Plant plant){
        Result result =new Result(plantImpl.add(plant));
        return result;
    }


    //删除操作
    @DeleteMapping("/{plant_id}")
    public Result delete(@PathVariable String plant_id){
        Result result =new Result(plantImpl.delete_by_plant_id(plant_id));
        return result;
    }


    //更新操作,JSON数据通过请求体传送过来
    @PutMapping
    public Result update(@RequestBody Plant plant){
        Result result =new Result(plantImpl.update_by_plant_id(plant));
        return result;
    }

    //更新操作,更新植物的病名为无
    @PutMapping("/{plant_id}")
    public Result update(@PathVariable String plant_id){
        Result result =new Result(plantImpl.update_disease_name(plant_id));
        return result;
    }

    //更新操作,更新植物的病名
    @PutMapping("/disease_name")
    public Result update_add_disease(@RequestBody Plant plant){
        Result result =new Result(plantImpl.update_add_disease(plant));
        return result;
    }


    //查询所有植物的操作
    @GetMapping
    public Result getByid(){
        //查询所有，默认返回true
        Result result =new Result(true,plantImpl.select_All());
        return result;
    }

    //查询所有有病名的植物
    @GetMapping("/disease")
    public Result get_disease(){
        //查询所有，默认返回true
        Result result =new Result(true,plantImpl.select_All_disease());
        return result;
    }

    //查询所有设备一的植物
    @GetMapping("/equipmentOne")
    public Result get_equipmentOne(){
        //查询所有，默认返回true
        Result result =new Result(true,plantImpl.select_All_equipment_one());
        return result;
    }

    //查询所有设备二的植物
    @GetMapping("/equipmentTwo")
    public Result get_equipmentTwo(){
        //查询所有，默认返回true
        Result result =new Result(true,plantImpl.select_All_equipment_two());
        return result;
    }

    //查询所有设备三的植物
    @GetMapping("/equipmentThird")
    public Result get_equipmentThird(){
        //查询所有，默认返回true
        Result result =new Result(true,plantImpl.select_All_equipment_third());
        return result;
    }




    //根据植物id查找植物
    @GetMapping("/{plant_id}")
    public Result get_one_Byid(@PathVariable String plant_id){
        //查询所有，默认返回true
        Result result =new Result(true,plantImpl.select_One(plant_id));
        return result;
    }



}
