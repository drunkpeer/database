package com.example.database_design.pojo;


import lombok.Data;

@Data
public class Disease {
    int disease_id;
    String disease_name;

}

//    CREATE TABLE DiseaseTable (
//        disease_id INT AUTO_INCREMENT PRIMARY KEY,-- 主键为int类型，且是自增
//        disease_name VARCHAR(100), -- 病虫害名称 对应植物基本信息的病名
//        );
