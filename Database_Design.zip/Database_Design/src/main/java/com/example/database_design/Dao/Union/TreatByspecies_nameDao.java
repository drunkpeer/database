package com.example.database_design.Dao.Union;


import com.example.database_design.UnionPojo.DrugByTreatPeople;
import com.example.database_design.UnionPojo.TreatByspecies_name;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface TreatByspecies_nameDao {

    @Select("SELECT * FROM TreatByspecies_name")
    public List<TreatByspecies_name> get_all();

    @Select("SELECT * FROM TreatByspecies_name where species_name=#{species_name}")
    public List<TreatByspecies_name> get_all_species_name(String species_name);




}
