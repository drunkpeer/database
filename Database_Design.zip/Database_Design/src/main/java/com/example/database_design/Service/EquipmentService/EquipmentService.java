package com.example.database_design.Service.EquipmentService;


import java.util.List;

public interface EquipmentService {



    public List<String> select_all_name();
}
