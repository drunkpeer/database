package com.example.database_design.Dao;


import com.example.database_design.pojo.Plant;
import com.example.database_design.pojo.Treatment;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

// 治疗表
@Mapper
public interface TreatmentDao {
    //增加（插入）一条治疗信息
    int insert_one(Treatment treatment);

    //删除一个治疗信息
    int delete_by_treat_id(int treat_id);  // 一般绝不会启用

    //通过养护id  更新（修改）一个植物信息
    int update_by_treat_id(Treatment treatment);

    //通过养护id  更新（修改）一个养护的养护状态和养护方法
    int update_prevent_method(Treatment treatment);

    //查找所有植物信息
    List<Treatment> select_All();

    //查找所有养护信息  1.植物的养护人是自己2.且状态是未治疗
    List<Treatment> select_my_disease(String user_name);

}
