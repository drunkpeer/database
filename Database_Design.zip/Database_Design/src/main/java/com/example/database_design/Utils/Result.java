package com.example.database_design.Utils;


import lombok.Data;

@Data
public class Result {
    Boolean flag;
    Object object;

    String message;

    public Result(){

    }
    public Result(Boolean flag){
        this.flag =flag;
    }
    public Result(Boolean flag,Object object){

        this.flag=flag;
        this.object=object;
    }


    public Result(Boolean flag,String message){
        this.flag=flag;
        this.message=message;
    }



}
