package com.example.database_design.Dao;


import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface EquipmentDao {


    @Select("select equipment_name from equipmenTable")
    public List<String> get_all_name();

}
