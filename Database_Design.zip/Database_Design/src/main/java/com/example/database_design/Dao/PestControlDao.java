package com.example.database_design.Dao;


import com.example.database_design.pojo.Disease;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;


@Mapper
@Repository
public interface PestControlDao {

    //增加（插入）一个植物分类信息
    int insert_one(Disease pestControl);

    //删除一个植物分类信息
    int delete_by_pestControl_id_id(String pestControl_id_id);

    //通过植物id  更新（修改）一个植物分类信息
    int update_by_pestControl_id_id(Disease pestControl);

    //查找所有植物分类信息
    List<Disease> select_All();

}
