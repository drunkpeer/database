package com.example.database_design.pojo;


import lombok.Data;

import java.util.Date;
//监测表
@Data
public class Monitor {
    int monitor_id;
    String plant_id;
    String monitor_people;
    int ph;
    int temperature;
    Date monitor_time;
    String monitor_location;

}
//    CREATE TABLE MonitorTable (
//        monitor_id INT AUTO_INCREMENT PRIMARY KEY,-- 主键为int类型，且是自增
//        plant_id VARCHAR(100),-- 监测对象，对应植物id
//        monitor_people VARCHAR(100), -- 监测人
//        ph INT , -- 默认1到14,不包含小数
//        temperature INT ,-- 默认是整数
//
//        -- 下面没用
//        monitor_time DATETIME, -- 检测时间
//        monitor_location VARCHAR(100), -- 检测地点
//        );
