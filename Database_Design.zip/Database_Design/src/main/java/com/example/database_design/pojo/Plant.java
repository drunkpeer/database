package com.example.database_design.pojo;


import lombok.Data;

import java.util.Date;

@Data
public class Plant {

    String plant_id;
    String species_name;
    String disease_name;
    String equipment_name;
//    上面是有用的 下面是没有太大用处的
    String image_id;
    String morphology;
    String cultivation_techniques;
    String application_value;
    String create_people ;
    Date create_time;
}

//    CREATE TABLE PlantTable (
//        plant_id VARCHAR(50) PRIMARY KEY,-- 植物id
//        species_name VARCHAR(100), -- 种名
//        disease_name VARCHAR(100) DEFAULT '无', -- 病名 创建的时候默认是无
//        equipment_name VARCHAR(100), -- 设备名称
//
//        -- 下面是没多大用的
//        image_id VARCHAR(50), -- 配图编号
//        morphology VARCHAR(255), -- 形态特征
//        cultivation_techniques VARCHAR(255), -- 栽培技术要点
//        application_value VARCHAR(255),-- 应用价值
//        create_people VARCHAR(100), -- 创建人
//        create_time DATETIME-- 创建时间
//        );
