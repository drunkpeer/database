package com.example.database_design.Service.UserService;


import com.example.database_design.Dao.UserDao;
import com.example.database_design.pojo.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserImpl implements UserService{

    @Autowired
    UserDao userDao;

    @Override
    public User select_one_user(String user_name) {
        return userDao.select_one_by_user(user_name);
    }

    @Override
    public List<User> get_all_employee() {
        return userDao.select_all_employee();
    }
}
