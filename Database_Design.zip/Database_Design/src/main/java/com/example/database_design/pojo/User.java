package com.example.database_design.pojo;


import lombok.Data;

@Data
public class User {
    int user_id;
    String user_name;
    String password;
    String role_name;

}
//    CREATE TABLE USER(
//        user_id INT AUTO_INCREMENT PRIMARY KEY ,
//        user_name VARCHAR(100),
//    PASSWORD VARCHAR(100),
//    role_name VARCHAR(100) -- 用户权限,分为四种 管理人员，监测人员 养护人员 上级部门
//        )
