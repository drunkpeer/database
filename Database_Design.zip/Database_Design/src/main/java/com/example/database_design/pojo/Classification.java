package com.example.database_design.pojo;


import lombok.Data;

@Data
public class Classification {
    int classification_id;
    String family_name;
    String genus_name;
    String species_name;
    String alias;
    String distribution_id;
    String growth_environment;

}

//    CREATE TABLE ClassificationTable (
//        classification_id INT AUTO_INCREMENT PRIMARY KEY, -- 分类id 主键为int类型，且是自增
//        family_name VARCHAR(100), -- 科名
//        genus_name VARCHAR(100),-- 属名
//        species_name VARCHAR(100), -- 种名
//        alias VARCHAR(100),-- 别名（中文俗语名称）
//        distribution_id VARCHAR(50),-- 分布区域的id
//        growth_environment VARCHAR(255) -- 生长环境
//        );
