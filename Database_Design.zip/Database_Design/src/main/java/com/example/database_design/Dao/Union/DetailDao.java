package com.example.database_design.Dao.Union;


import com.example.database_design.UnionPojo.Detail;
import com.example.database_design.UnionPojo.DrugByTreatPeople;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DetailDao {


    @Select("Select * from detail")
    public List<Detail> get_all_detail();

    @Select("Select * from detail where species_name=#{species_name}")
    public List<Detail> get_detail_byspecies_name(String species_name);

}
