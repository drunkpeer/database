package com.example.database_design.Service.ClassificationService;


import com.example.database_design.Dao.ClassificationDao;
import com.example.database_design.pojo.Classification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ClassificationImpl implements ClassificationService {

    @Autowired
    ClassificationDao classificationDao;

    @Override
    public Boolean insert(Classification classification) {
        return classificationDao.insert_one(classification)>0;
    }

    @Override
    public Boolean delete(int classification_id) {
        return classificationDao.delete_by_classification_id(classification_id)>0;
    }

    @Override
    public Boolean update(Classification classification) {
        return null;
    }

    @Override
    public List<Classification> select_All() {
        return classificationDao.select_All();
    }

    @Override
    public List<Classification> select_One(int classification_id) {
        return classificationDao.select_One(classification_id);
    }

    @Override
    public List<Classification> select_query(Classification classification) {
        return classificationDao.select_query(classification);
    }


}
