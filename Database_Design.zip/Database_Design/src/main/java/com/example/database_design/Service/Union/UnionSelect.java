package com.example.database_design.Service.Union;


import com.example.database_design.Dao.Union.*;
import com.example.database_design.UnionPojo.*;
import com.example.database_design.pojo.Distribution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UnionSelect {

    @Autowired
    DrugByTreatPeopleDao drugByTreatPeopleDao;
    @Autowired
    TreatByspecies_nameDao treatByspecies_nameDao;
    @Autowired
    EquipmentByMonitorpeopleDao equipmentByMonitorpeopleDao;

    @Autowired
    PestByAreaDao pestByAreaDao;

    @Autowired
    DetailDao detailDao;



    public List<DrugByTreatPeople> getAll(){

        return drugByTreatPeopleDao.get_all();
    }
    public List<DrugByTreatPeople> get_treat_people(String treat_people){

        return drugByTreatPeopleDao.get_all_treatpeople(treat_people);
    }

    //分隔符。。。。。。。。。。。。。。。。。。。。。。
    public List<TreatByspecies_name> get_all_species(){
        return treatByspecies_nameDao.get_all();
    }

    public List<TreatByspecies_name> get_all_species_name(String species_name){
        return treatByspecies_nameDao.get_all_species_name(species_name);
    }

    //分隔符。。。。。。。。。。。。。。。。。。。。。。

    public List<EquipmentByMonitorpeople> get_all_Equipment(){
        return equipmentByMonitorpeopleDao.get_all();
    }

    public List<EquipmentByMonitorpeople> get_all_Monitorpeople(String Monitorpeople){
        return equipmentByMonitorpeopleDao.get_all_monitor_people(Monitorpeople);
    }


    //分类条。。。。。。。。。
    public List<PestByArea> get_all_pest(){
        return pestByAreaDao.get_all();
    }

    public List<PestByArea> get_pest(Distribution distribution){
        return pestByAreaDao.get_all_Pest_name(distribution);
    }

    //分类条....................
    public List<Detail> get_all_detail(){
        return detailDao.get_all_detail();
    }

    public List<Detail> get_detail_by_species(String species_name){
        return detailDao.get_detail_byspecies_name(species_name);
    }






}
