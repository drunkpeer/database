package com.example.database_design.Controller;


import com.example.database_design.Service.TreatmentService.TreatmentService;
import com.example.database_design.Utils.Result;
import com.example.database_design.pojo.Treatment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/treatments")
public class TreatmentController {

    @Autowired
    TreatmentService treatmentService;

    @PostMapping
    public Result insert_one(@RequestBody Treatment treatment){
        return new Result(treatmentService.add(treatment));
    }

    @PutMapping("/prevent_methods")
    public Result update_prevent_methods(@RequestBody Treatment treatment){
        return new Result(treatmentService.update_prevet_method(treatment));
    }


    //查询养护表里面的所有养护记录
    @GetMapping("/getall")
    public Result get_all(){
        //查询所有，默认返回true
        return new Result(true,treatmentService.select_All());
    }


    //查询该植物的养护人是自己的且该植物的状态是未养护
    @GetMapping("/disease/{user_name}")
    public Result get_disease(@PathVariable String user_name){
        //查询所有，默认返回true
        return new Result(true,treatmentService.select_my_disease(user_name));
    }



}
