package com.example.database_design.Controller;


import com.example.database_design.Service.MonitorService.MonitorService;
import com.example.database_design.Utils.Result;
import com.example.database_design.pojo.Monitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/monitors")
public class MonitorController {

    @Autowired
    MonitorService monitorService;


    @PostMapping
    public Result insert_one(@RequestBody Monitor monitor){
        return new Result(monitorService.insert_one(monitor));
    }

    @GetMapping ("/getall")
    public Result get_all(){
        return new Result(true,monitorService.get_all());
    }



}
