package com.example.database_design.Service.PlantService;


import com.example.database_design.pojo.Plant;
import org.springframework.stereotype.Service;

import java.util.List;


public interface PlantService {

    Boolean add(Plant plant); //对应着Dao的insert

    Boolean delete_by_plant_id(String plant_id);

    Boolean update_by_plant_id(Plant plant);

    Boolean update_disease_name(String plant_id);

    Boolean update_add_disease(Plant plant);



    List<Plant> select_All();

    List<Plant> select_All_disease();


    List<Plant> select_All_equipment_one();

    List<Plant> select_All_equipment_two();

    List<Plant> select_All_equipment_third();


    Plant select_One(String plant_id);



}
