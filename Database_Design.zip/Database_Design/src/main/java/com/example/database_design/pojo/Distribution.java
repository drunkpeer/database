package com.example.database_design.pojo;


import lombok.Data;

@Data
public class Distribution {
    String distribution_id;
    String province;
    String city;
    String town;
}
//这个表相当于已经给好了，不需要我们写别的了
