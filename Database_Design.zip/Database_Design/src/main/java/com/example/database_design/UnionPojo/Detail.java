package com.example.database_design.UnionPojo;


import lombok.Data;



@Data
public class Detail {
    String species_name;
    String family_name;
    String genus_name;
    String province;
    String city;
    String town;

}
//
//    SELECT classificationtable.species_name AS species_name,
//        classificationtable.family_name AS family_name,
//        classificationtable.genus_name AS genus_name,
//        distributiontable.province AS province,
//        distributiontable.city AS city,
//        distributiontable.town AS town
