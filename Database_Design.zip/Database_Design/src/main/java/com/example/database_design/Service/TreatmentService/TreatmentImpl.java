package com.example.database_design.Service.TreatmentService;


import com.example.database_design.Dao.TreatmentDao;
import com.example.database_design.pojo.Treatment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TreatmentImpl implements TreatmentService{

    @Autowired
    TreatmentDao treatmentDao;

    @Override
    public Boolean add(Treatment treatment) {
        return treatmentDao.insert_one(treatment)>0;
    }

    @Override
    public Boolean delete_by_treat_id(int treat_id) {
        return treatmentDao.delete_by_treat_id(treat_id)>0;
    }

    @Override
    public Boolean update_by_treat_id(Treatment treatment) {
        return treatmentDao.update_by_treat_id(treatment)>0;
    }

    @Override
    public Boolean update_prevet_method(Treatment treatment) {
        return treatmentDao.update_prevent_method(treatment)>0;
    }

    @Override
    public List<Treatment> select_All() {
        return treatmentDao.select_All();
    }

    @Override
    public List<Treatment> select_my_disease(String user_name) {
        return treatmentDao.select_my_disease(user_name);
    }

    @Override
    public Treatment select_One(int treat_id) {
        return null;
    }
}
