package com.example.database_design.pojo;


import lombok.Data;

@Data
public class Treatment {
    int treat_id;
    String disease_name;
    String prevent_method;
    String plant_id;
    String treat_people;
    String treat_state;

    String treat_time;
    String create_time;
}

//3.治疗表
//        CREATE TABLE TreatmentTable (
//        treat_id INT AUTO_INCREMENT PRIMARY KEY, -- 养护id 主键为int类型，且是自增
//        disease_name VARCHAR(100), -- 病名 对应报告书里的的任务名
//        prevent_method VARCHAR(255),-- 防治措施 对应报告书里的的任务描述
//        plant_id VARCHAR(100),-- 养护对象，对应植物编号
//        treat_people VARCHAR(100),-- 对应的养护人 由管理人员选择
//        treat_state -- 治疗状态，分为未治疗 和已经治疗
//        -- 下面是没多大用的
//        treat_time DATE, -- 养护时间
//        create_time DATETIME, -- 创建时间
//        );