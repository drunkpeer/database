package com.example.database_design.Service.EquipmentService;


import com.example.database_design.Dao.EquipmentDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EquipmentImpl implements EquipmentService{

    @Autowired
    EquipmentDao equipmentDao;

    @Override
    public List<String> select_all_name() {
        return equipmentDao.get_all_name();
    }
}
