package com.example.database_design.Service.MonitorService;


import com.example.database_design.Dao.MonitorDao;
import com.example.database_design.pojo.Monitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MonitorImpl implements MonitorService{

    @Autowired
    MonitorDao monitorDao;


    @Override
    public Boolean insert_one(Monitor monitor) {
        return monitorDao.insert_one(monitor)>0;
    }

    @Override
    public List<Monitor> get_all() {
        return monitorDao.select_All();
    }
}
