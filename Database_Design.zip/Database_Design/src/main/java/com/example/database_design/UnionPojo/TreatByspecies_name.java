package com.example.database_design.UnionPojo;


import lombok.Data;


//CREATE VIEW TreatByspecies_name AS
//        SELECT
//        planttable.species_name AS species_name,
//        planttable.disease_name AS disease_name,
//        treatmenttable.treat_people AS treat_people,
//        treatmenttable.treat_time AS treat_time,
//        treatmenttable.prevent_method AS prevent_method,
//        preventtable.drug_name AS drug_name,
//        preventtable.drug_amount AS drug_amount
//        FROM planttable
//        JOIN treatmenttable ON planttable.plant_id = treatmenttable.plant_id
//        JOIN preventtable ON treatmenttable.prevent_method = preventtable.prevent_method

@Data
public class TreatByspecies_name {
    String species_name;
    String disease_name;
    String treat_people;
    String treat_time;
    String prevent_method;
    String drug_name;
    String drug_amount;
}
