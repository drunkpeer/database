package com.example.database_design.Controller;


import com.example.database_design.Dao.DistributionDao;
import com.example.database_design.Utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/distributions")
public class DistributionController {

    @Autowired
    DistributionDao distributionDao;

    @GetMapping("/{distribution_id}")
    public Result get_one(@PathVariable  String distribution_id){
        return new Result(true,distributionDao.select_One(distribution_id));
    }


}
