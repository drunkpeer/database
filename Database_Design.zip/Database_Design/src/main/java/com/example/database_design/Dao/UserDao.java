package com.example.database_design.Dao;


import com.example.database_design.pojo.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserDao {



    @Select("select * from user where user_name = #{user_name}")
    public User select_one_by_user(String user_name);

    @Select("select * from user where role_name='监测人员' or role_name='养护人员'")
    public List<User> select_all_employee();




}
