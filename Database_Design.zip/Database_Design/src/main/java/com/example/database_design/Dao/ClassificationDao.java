package com.example.database_design.Dao;


import com.example.database_design.pojo.Plant;
import com.example.database_design.pojo.Classification;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;


//分类表
@Mapper
@Repository
public interface ClassificationDao {

    //增加（插入）一个植物分类信息
    int insert_one(Classification classification);

    //删除一个植物分类信息
    int delete_by_classification_id(int classification_id);

    //通过植物id  更新（修改）一个植物分类信息
    int update_by_classification_id(Classification classification);

    //查找所有植物分类信息
    List<Classification> select_All();

    //查找一个植物分类信息
    List<Classification> select_One(int classification_id);


    //根据科名，属名，或者别名查找信息
    @Select("select * from ClassificationTable where family_name=#{family_name} or " +
            " genus_name = #{genus_name}  or species_name = #{species_name} ")
    List<Classification> select_query(Classification classification);



}
