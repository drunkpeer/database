package com.example.database_design.Service.PreventService;

import com.example.database_design.Dao.PreventDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class PreventImpl implements PreventService{

    @Autowired
    PreventDao preventDao;

    @Override
    public List<String> select_all_names() {

        return preventDao.select_All_names();
    }
}
