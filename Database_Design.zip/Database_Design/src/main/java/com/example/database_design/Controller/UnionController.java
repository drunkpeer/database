package com.example.database_design.Controller;


import com.example.database_design.Service.Union.UnionSelect;
import com.example.database_design.Utils.Result;
import com.example.database_design.pojo.Distribution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/unions")
public class UnionController {


    @Autowired
    UnionSelect unionSelect;

    @GetMapping("/drugByTreatpeople")
    public Result drugByTreatpeople(){
        return new Result(true,unionSelect.getAll());
    }

    @GetMapping("/drugByTreatpeople/{treat_people}")
    public Result get_treatpeople(@PathVariable String treat_people){
        return new Result(true,unionSelect.get_treat_people(treat_people));
    }

    //分隔符。。。。。。。。。。。。。。。。。。。。
    @GetMapping("/TreatByspecies_name")
    public Result TreatByspecies_name(){
        return new Result(true,unionSelect.get_all_species());
    }

    @GetMapping("/TreatByspecies_name/{species_name}")
    public Result get_treat(@PathVariable String species_name){
        return new Result(true,unionSelect.get_all_species_name(species_name));
    }


    //分隔符。。。。。。。。。。。。。。。。。。。。
    @GetMapping("/equipmentByMonitorpeople")
    public Result equipmentByMonitorpeople(){
        return new Result(true,unionSelect.get_all_Equipment());
    }

    @GetMapping("/equipmentByMonitorpeople/{monitor_people}")
    public Result get_equipment(@PathVariable String monitor_people){
        return new Result(true,unionSelect.get_all_Monitorpeople(monitor_people));
    }

    //分隔符..............................
    @GetMapping("/PestByArea")
    public Result PestByArea(){
        return new Result(true,unionSelect.get_all_pest());
    }

    @PostMapping("/PestByArea/distribution")
    public Result get_PestByArea(@RequestBody Distribution distribution){
        return new Result(true, unionSelect.get_pest(distribution));
    }

    //分隔符。。。。。。。。。。。。。。。。。。。
    @GetMapping("/detail")
    public Result Detail(){
        return new Result(true,unionSelect.get_all_detail());
    }
    @GetMapping("/detail/{species_name}")
    public Result getBYspecies(@PathVariable String species_name){
        return new Result(true,unionSelect.get_detail_by_species(species_name));
    }



}
