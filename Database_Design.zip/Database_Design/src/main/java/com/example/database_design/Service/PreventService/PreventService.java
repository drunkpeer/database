package com.example.database_design.Service.PreventService;


import java.util.List;

public interface PreventService {

    List<String> select_all_names();


}
