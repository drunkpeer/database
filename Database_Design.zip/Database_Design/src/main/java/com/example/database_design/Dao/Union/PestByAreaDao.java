package com.example.database_design.Dao.Union;

import com.example.database_design.UnionPojo.PestByArea;
import com.example.database_design.UnionPojo.TreatByspecies_name;
import com.example.database_design.pojo.Distribution;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PestByAreaDao {

    @Select("select * from PestByArea")
    public List<PestByArea> get_all();

    @Select("SELECT * FROM PestByArea where province=#{province} or city=#{city} or town=#{town}")
    public List<PestByArea> get_all_Pest_name(Distribution distribution);



}
