package com.example.database_design.Dao;


import com.example.database_design.pojo.Plant;
import com.example.database_design.pojo.Prevent;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface PreventDao {

    //增加（插入）一个防治信息
    int insert_one(Prevent prevent);

    //删除一个防治信息
    int delete_by_prevent_id(int prevent_id);

    //通过植物id  更新（修改）一个植物信息
    int update_by_perevent_id(Prevent prevent);

    //查找所有防治信息
    List<Prevent> select_All();

    //查找所有防治方法信息的名字
    List<String> select_All_names();


}
