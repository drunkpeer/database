package com.example.database_design.Service.UserService;


import com.example.database_design.pojo.User;

import java.util.List;

public interface UserService {

    public User select_one_user(String user_name);

    public List<User> get_all_employee();

}
