package com.example.database_design.Controller;


import com.example.database_design.Service.UserService.UserService;
import com.example.database_design.Utils.Result;
import com.example.database_design.pojo.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins ="*")
@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    UserService userService;



    @GetMapping
    public Result select_one_user(User user){
        User user1 = userService.select_one_user(user.getUser_name());
        Result result;
        if(user1==null){
            result=new Result(true,"该用户不存在");

            return result;
        }else if(!user1.getPassword().equals(user.getPassword())){
            result=new Result(true,"密码错误");

            return result;
        }else{

            //如果用户存在而且密码正确，返回完整的数值
            result=new Result(true,user1);

            return result;
        }

    }

    @GetMapping("/getall")
    public Result getall(){
        return new Result(true,userService.get_all_employee());
    }




}
