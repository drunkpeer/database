package com.example.database_design.Service.TreatmentService;

import com.example.database_design.pojo.Plant;
import com.example.database_design.pojo.Treatment;

import java.util.List;

public interface TreatmentService {


    Boolean add(Treatment treatment); //对应着Dao的insert

    Boolean delete_by_treat_id(int treat_id);

    Boolean update_by_treat_id(Treatment treatment);


    Boolean update_prevet_method(Treatment treatment);


    List<Treatment> select_All();

    List<Treatment> select_my_disease(String user_name);

    Treatment select_One(int treat_id);




}
