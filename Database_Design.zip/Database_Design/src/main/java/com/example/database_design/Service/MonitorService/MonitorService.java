package com.example.database_design.Service.MonitorService;


import com.example.database_design.pojo.Monitor;

import java.util.List;

public interface MonitorService {


    Boolean insert_one(Monitor monitor);

    List<Monitor> get_all();

}
