package com.example.database_design.UnionPojo;


import lombok.Data;


//CREATE VIEW drugByTreatpeople AS
//        SELECT t.treat_people AS treat_people,
//        p.species_name AS species_name,
//        p.disease_name AS disease_name,
//        pr.drug_name AS drug_name,
//        pr.drug_amount AS drug_amount
//        FROM treatmenttable t
//        JOIN planttable p ON t.plant_id = p.plant_id
//        JOIN preventtable pr ON t.prevent_method = pr.prevent_method
//

@Data
public class DrugByTreatPeople {
    String treat_people;
    String species_name;
    String disease_name;
    String drug_name;
    String drug_amount;

}
