package com.example.database_design.Dao.Union;


import com.example.database_design.UnionPojo.DrugByTreatPeople;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface DrugByTreatPeopleDao {


    @Select("SELECT * FROM drugByTreatpeople")
    public List<DrugByTreatPeople> get_all();

    @Select("SELECT * FROM drugByTreatpeople where treat_people=#{treat_people}")
    public List<DrugByTreatPeople> get_all_treatpeople(String treat_people);



}
