package com.example.database_design.Service.ClassificationService;


import com.example.database_design.pojo.Classification;

import java.util.List;

public interface ClassificationService {

   // 增
    Boolean insert(Classification classification);
   // 删
    Boolean delete(int classification_id);
   // 改
    Boolean update(Classification classification);
    //查所有
    List<Classification> select_All();
    //查单个
    List<Classification> select_One(int classification_id);

    List<Classification> select_query(Classification classification);


}
