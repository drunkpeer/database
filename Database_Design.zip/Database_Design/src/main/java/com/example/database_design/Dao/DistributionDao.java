package com.example.database_design.Dao;


import com.example.database_design.pojo.Distribution;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface DistributionDao {

    @Select("select * from distributionTable where distribution_id=#{distribution_id}")
    public Distribution select_One(String distribution_id);


}
