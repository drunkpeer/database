package com.example.database_design.Dao;

import com.example.database_design.pojo.Monitor;
import com.example.database_design.pojo.Plant;
import com.example.database_design.pojo.Treatment;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;




//监测表
//int monitor_id;
//        String plant_id;
//        String monitor_people;
//        int ph;
//        int temperature;
//
//
//        Date monitor_time;
//        String monitor_location;
@Mapper
public interface MonitorDao {


    //增加（插入）一条监测信息
    int insert_one(Monitor monitor);

    //删除一个监测信息
    int delete_by_monitor_id(int monitor_id);  // 一般绝不会启用

    //通过监视id  更新（修改）一个监测信息
    int update_by_treat_id(Monitor monitor);

    //查找所有植物信息
    List<Monitor> select_All();
}
